#pragma once

#include "resource.h"

LRESULT OnReceiveStr(WPARAM str, LPARAM commInfo);
